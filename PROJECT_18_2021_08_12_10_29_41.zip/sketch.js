var fruit,bananaImage;
var obstacle,obstacleImage,obstacleGroup;
var background,invisibleGround;
var score = 0; 
var animal;

function preload() {
  backImage = loadImage("jungle.jpg");
  player_running = loadAnimation("Monkey_01.png","Monkey_02.png","Monkey_03.png","Monkey_04.png","Monkey_05.png","Monkey_06.png","Monkey_07.png","Monkey_08.png","Monkey_09.png","Monkey_10.png");
  bananaImage = loadImage("banana.png");
  obstacle_img = loadImage("stone.png");
}

function setup() {
  createCanvas(400, 400);
  
  backgroundImg = createSprite(200,200,400,400);
  backgroundImg.addImage(backImage);
  backgroundImg.velocityX = -4;
  backgroundImg.x = backgroundImg.width/2;
  animal = createSprite(50,340);
  animal.scale = 0.2;
  animal.addAnimation("running",player_running);
  
  invisibleGround = createSprite(400,390,800,10);
  invisibleGround.visible = false;
  
  fruitGroup = new Group();
  obstaclesGroup = new Group();
  
  score = 0;
  
}

function draw() {
  background(220);
  
  stroke("white");
  textSize(20);
  fill("white");
  text("Score: "+ score, 500,50); 
  
 
  
  if (backgroundImg.x < 0){
      backgroundImg.x = backgroundImg.width/2;
    }
  
  
          //camera.position.y = displayHeight/2;
  
  if (keyDown("space") && animal.y >= 325) {
   animal.velocityY = -11; 
  }
  animal.velocityY = animal.velocityY + 0.4;
  
 fruits();
 obstacles();
  
 if (fruitGroup.isTouching(animal)) {
   
   fruitGroup.destroyEach();
   
   switch(score) {
     case 10 : animal.scale = 0.12;
              break;
     case 20 : animal.scale = 0.14;
              break;
     case 30 : animal.scale = 0.16;
              break;
     case 40 : animal.scale = 0.18;
              break;
     default : break;         
   }
   
 }
  
 if (obstaclesGroup.isTouching(animal)) {
   animal.scale = 0.2;
 } 
  
  createEdgeSprites();
 animal.collide(invisibleGround);
  
  
  
  drawSprites();
  
  camera.position.x = animal.position.x;
}

function fruits() {
  
  if (frameCount % 80 === 0) {
  
  var  fruit = createSprite(400,190);
  fruit.y = Math.round(random(100,200));
  fruit.addImage("fruit",bananaImage);
  fruit.velocityX = -3;
  fruit.scale = 0.05;
  fruit.lifetime = 200;
  
  
  fruitGroup.add(fruit);
  
  }
}

function obstacles() {
  
  if (frameCount%300===0) {
  
 var obstacle = createSprite(400,360);
 obstacle.velocityX = -10;
 obstacle.addImage("stone",obstacle_img);
 obstacle.scale = 0.15;
 obstacle.lifetime = 40;

 obstaclesGroup.add(obstacle);
 
  } 
}